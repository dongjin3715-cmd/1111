"""UI-free sequential task engine. All network side effects are in adapters.py."""
import random
import threading
import time
from datetime import datetime


class Cancelled(Exception):
    pass


class Control:
    def __init__(self):
        self.cancelled = threading.Event()
        self.running = threading.Event()
        self.running.set()

    def pause(self):
        self.running.clear()

    def resume(self):
        self.running.set()

    def stop(self):
        self.cancelled.set()
        self.running.set()

    def checkpoint(self):
        while not self.running.wait(.1):
            if self.cancelled.is_set():
                raise Cancelled()
        if self.cancelled.is_set():
            raise Cancelled()

    def wait(self, seconds):
        remaining = seconds
        while remaining > 0:
            self.checkpoint()
            start = time.monotonic()
            if self.cancelled.wait(min(.1, remaining)):
                raise Cancelled()
            remaining -= time.monotonic() - start
        self.checkpoint()


class Engine:
    def __init__(self, accounts, cafes, nicknames, drafts, profiles, options,
                 adapter_factory, emit=lambda kind, value: None, prompt=lambda text: "", control=None):
        self.accounts, self.cafes = accounts, cafes
        self.nicknames, self.drafts, self.profiles = nicknames, drafts, profiles
        self.options, self.adapter_factory = options, adapter_factory
        self.emit, self.prompt = emit, prompt
        self.control = control or Control()
        self.records = []
        self.index = 0

    def log(self, text):
        self.emit("log", text)

    def record(self, account, cafe, nickname, result):
        row = [account.username, cafe.address if cafe else "", nickname,
               datetime.now().astimezone().isoformat(timespec="seconds"), result]
        # Never persist passwords, tokens, cookies or full exception response bodies.
        self.records.append(row)
        self.emit("record", row)

    def run(self):
        self.options.validate()
        if not self.accounts or not self.cafes:
            raise ValueError("계정과 카페 목록이 필요합니다.")
        if self.options.greeting and not self.drafts:
            raise ValueError("가입인사를 선택하면 원고 폴더가 필요합니다.")
        total = len(self.accounts) * len(self.cafes)
        done = 0
        try:
            for account in self.accounts:
                self.control.checkpoint()
                adapter = self.adapter_factory(self.control, self.prompt, self.log)
                try:
                    self.log(f"{account.username}: 로그인 준비")
                    adapter.login(account, self.options)
                    for cafe in self.cafes:
                        self.control.checkpoint()
                        nickname = (self.nicknames[self.index % len(self.nicknames)] if self.nicknames
                                    else f"초록{random.randint(1000, 9999)}")
                        profile = None
                        if self.profiles:
                            profile = (random.choice(self.profiles) if self.options.random_profile
                                       else self.profiles[self.index % len(self.profiles)])
                        try:
                            result = adapter.join(cafe, nickname, profile, self.options)
                            self.record(account, cafe, nickname, result)
                            active = result == "가입 완료" or (result == "이미 가입" and self.options.include_existing)
                            if active:
                                self.control.checkpoint()
                                adapter.visit(cafe)
                                if self.options.favorite:
                                    self.control.checkpoint()
                                    adapter.favorite(cafe)
                                    self.record(account, cafe, nickname, "즐겨찾기 완료")
                                if self.options.greeting:
                                    self.control.checkpoint()
                                    if not cafe.menu_id:
                                        self.record(account, cafe, nickname, "가입인사 건너뜀: 메뉴 ID 없음")
                                    else:
                                        draft = self.drafts[self.index % len(self.drafts)]
                                        article = adapter.post(cafe, draft, nickname, self.options)
                                        self.record(account, cafe, nickname, f"가입인사 완료: {article}")
                        except Cancelled:
                            raise
                        except Exception as exc:
                            self.record(account, cafe, nickname, adapter.safe_error(exc))
                        self.index += 1
                        done += 1
                        self.emit("progress", (done, total))
                        if done < total:
                            delay = random.randint(self.options.delay_min, self.options.delay_max)
                            self.log(f"다음 작업까지 {delay}초 대기")
                            self.control.wait(delay)
                except Cancelled:
                    raise
                except Exception as exc:
                    self.record(account, None, "", adapter.safe_error(exc))
                    # Failed login consumes remaining cafe slots for this account.
                    skipped = len(self.cafes)
                    done += skipped
                    self.emit("progress", (done, total))
                finally:
                    adapter.close()
            self.emit("finished", "완료")
        except Cancelled:
            self.emit("finished", "중지됨")


class SimulationAdapter:
    def __init__(self, control, prompt, log):
        self.control, self.log = control, log

    def login(self, account, options):
        self.log("모의 실행: 네이버에 접속하거나 실제 작업하지 않습니다.")

    def join(self, cafe, nickname, profile, options):
        self.control.checkpoint()
        self.log(f"모의 가입: {cafe.address} / {nickname}")
        return "가입 완료"

    def visit(self, cafe):
        self.log(f"모의 방문: {cafe.address}")

    def favorite(self, cafe):
        self.log(f"모의 즐겨찾기: {cafe.address}")

    def post(self, cafe, draft, nickname, options):
        self.log(f"모의 가입인사: {draft.title.replace('[닉네임]', nickname)}")
        return "SIMULATION"

    @staticmethod
    def safe_error(exc):
        return "작업 오류: " + type(exc).__name__

    def close(self):
        pass
