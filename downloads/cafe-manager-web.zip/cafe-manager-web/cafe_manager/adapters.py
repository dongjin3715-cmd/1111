"""Naver integration based on supplied request formats; remote compatibility is unverified.

No seller authentication, bundled binaries, detection evasion or external captcha service
is reused. TLS verification stays enabled. Writes are never automatically retried.
"""
import json
import mimetypes
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

import requests

from .engine import Cancelled
from .models import answer_for

API = "https://apis.naver.com"


class ServiceError(Exception):
    """Contains only an application-authored, credential-free explanation."""


def at(data, path, default=None):
    for key in path.split("."):
        if not isinstance(data, dict) or key not in data:
            return default
        data = data[key]
    return data


def result_of(data):
    if not isinstance(data, dict):
        raise ServiceError("서버 응답 형식이 변경되었습니다.")
    if "message" in data:
        message = data["message"]
        if str(message.get("status")) != "200":
            raise ServiceError("네이버가 요청을 거절했습니다. 브라우저에서 계정 상태를 확인하세요.")
        return message.get("result", {})
    if data.get("error"):
        raise ServiceError("네이버가 요청을 거절했습니다. 권한 또는 API 형식을 확인하세요.")
    if "result" in data:
        return data["result"]
    raise ServiceError("예상한 결과 항목이 없습니다. API 호환성을 확인하세요.")


def document_payload(cafe_id, menu_id, editor_id, draft, nickname, comments):
    def uid():
        return "SE-" + str(uuid.uuid4())
    paragraphs = []
    for line in draft.body.replace("[닉네임]", nickname).splitlines():
        node = {"id": uid(), "value": line, "@ctype": "textNode"}
        paragraphs.append({"id": uid(), "nodes": [node], "@ctype": "paragraph"})
    content = {"document": {"version": "2.8.8", "theme": "default", "language": "ko-KR",
                            "id": editor_id, "components": [
                                {"id": uid(), "layout": "default", "value": paragraphs, "@ctype": "text"}]},
               "documentId": ""}
    return {"article": {"cafeId": str(cafe_id), "menuId": int(menu_id),
                         "subject": draft.title.replace("[닉네임]", nickname),
                         "contentJson": json.dumps(content, ensure_ascii=False),
                         "from": "pc", "tagList": [], "editorVersion": 4, "parentId": 0,
                         "open": False, "naverOpen": True, "externalOpen": True,
                         "enableComment": comments, "enableScrap": True, "enableCopy": True,
                         "useAutoSource": False, "cclTypes": [], "useCcl": False}}


class NaverAdapter:
    def __init__(self, control, prompt, log, session=None):
        self.control, self.prompt, self.log = control, prompt, log
        self.session = session or requests.Session()
        self.driver = None
        self.ids = {}
        self.session.headers.update({"Accept": "application/json, text/plain, */*",
                                     "X-Cafe-Product": "mweb", "Origin": "https://m.cafe.naver.com"})

    @staticmethod
    def safe_error(exc):
        if isinstance(exc, ServiceError):
            return str(exc)
        if isinstance(exc, requests.Timeout):
            return "응답 시간 초과: 작업내역을 네이버에서 확인한 뒤 다시 실행하세요."
        if isinstance(exc, requests.RequestException):
            return "네트워크 오류: 처리 여부를 확인한 뒤 다시 실행하세요."
        return "작업 오류: " + type(exc).__name__

    def request(self, method, url, **kwargs):
        self.control.checkpoint()
        host = urlparse(url).hostname
        if host not in {"apis.naver.com", "upapi.cafe.naver.com", "platform.editor.naver.com", "m.cafe.naver.com"}:
            raise ServiceError("허용된 네이버 서비스 주소가 아닙니다.")
        # No retry on writes: a timeout may happen after the server has applied a request.
        try:
            response = self.session.request(method, url, timeout=(10, 30), allow_redirects=False, **kwargs)
        except requests.RequestException:
            if method.upper() != "GET":
                raise ServiceError("요청 결과 불명: 네이버에서 처리 여부를 확인하세요. 자동 재전송하지 않습니다.") from None
            raise
        if response.status_code in (401, 403):
            raise ServiceError("로그인 또는 접근 권한을 확인하세요.")
        if response.status_code == 429:
            raise ServiceError("요청 제한에 도달했습니다. 작업을 멈추고 나중에 다시 시도하세요.")
        if not 200 <= response.status_code < 300:
            raise ServiceError(f"서버 응답 오류 (HTTP {response.status_code}). 처리 여부를 확인하세요.")
        return response

    def json(self, method, url, **kwargs):
        response = self.request(method, url, **kwargs)
        try:
            return response.json()
        except ValueError:
            raise ServiceError("JSON 응답을 받지 못했습니다. 로그인 또는 API 호환성을 확인하세요.") from None

    def sync_cookies(self):
        for cookie in self.driver.get_cookies():
            domain = cookie.get("domain", "")
            if domain.lstrip(".") == "naver.com" or domain.endswith(".naver.com"):
                self.session.cookies.set(cookie["name"], cookie["value"], domain=domain,
                                         path=cookie.get("path", "/"), secure=cookie.get("secure", True))

    def login(self, account, options):
        from selenium import webdriver
        from selenium.webdriver.common.by import By
        chrome = webdriver.ChromeOptions()
        chrome.add_argument("--incognito")
        chrome.add_argument("--disable-notifications")
        self.driver = webdriver.Chrome(options=chrome)
        self.driver.set_page_load_timeout(45)
        self.driver.get("https://nid.naver.com/nidlogin.login")
        if not options.manual_login:
            if not account.password:
                raise ServiceError("자동 로그인에 필요한 비밀번호가 없습니다.")
            self.driver.find_element(By.ID, "id").send_keys(account.username)
            self.driver.find_element(By.ID, "pw").send_keys(account.password)
            self.driver.find_element(By.ID, "log.login").click()
        self.log(f"{account.username}: 열린 Chrome에서 로그인하세요. 추가 인증은 직접 처리하세요.")
        deadline = time.monotonic() + options.login_timeout
        while time.monotonic() < deadline:
            self.control.checkpoint()
            names = {c["name"] for c in self.driver.get_cookies()}
            if {"NID_AUT", "NID_SES"} <= names:
                self.sync_cookies()
                self.session.headers["User-Agent"] = self.driver.execute_script("return navigator.userAgent")
                # The login window is isolated per account; the user verifies the intended ID.
                self.prompt(f"{account.username} 계정으로 로그인했는지 확인하고 계속을 누르세요.")
                self.log("로그인 세션 확인 완료")
                return
            self.control.wait(.5)
        raise ServiceError("로그인 대기시간이 초과되었습니다.")

    def cafe_id(self, cafe):
        if cafe.address in self.ids:
            return self.ids[cafe.address]
        if cafe.address.isdigit():
            value = cafe.address
        else:
            data = self.json("GET", API + "/cafe-web/cafe2/CafeGateInfo.json", params={"cluburl": cafe.address})
            value = at(result_of(data), "cafeInfoView.cafeId")
        if not value or not str(value).isdigit():
            raise ServiceError("카페 ID를 찾지 못했습니다.")
        self.ids[cafe.address] = str(value)
        return str(value)

    def view(self, cafe_id):
        data = self.json("GET", API + "/cafe-web/cafe-mobile/CafeApplyView.json", params={"cafeId": cafe_id})
        error = str(at(data, "message.error.msg", ""))
        if "이미 회원" in error or "이미 가입" in error:
            return None
        return result_of(data)

    def upload_profile(self, cafe_id, path):
        path = Path(path)
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        with path.open("rb") as image:
            raw = image.read()
        data = self.json("POST", f"https://upapi.cafe.naver.com/v1.0/cafes/{cafe_id}/images/cafeMemberProfile",
                         files={"imagefile": (path.name, raw, content_type), "file": (path.name, raw, content_type)},
                         data={"requestInputId": "img_upload", "name": path.name, "type": content_type})
        value = at(result_of(data), "path")
        if not value:
            raise ServiceError("프로필 이미지 업로드 결과를 확인하지 못했습니다.")
        return value

    def join(self, cafe, nickname, profile, options):
        cafe_id = self.cafe_id(cafe)
        referer = f"https://m.cafe.naver.com/ca-fe/web/cafes/{cafe_id}/join"
        self.session.headers["Referer"] = referer
        view = self.view(cafe_id)
        if view is None:
            return "이미 가입"
        if at(view, "mobileCafeApplyCaptcha.needCaptcha") in (True, "true", "True"):
            self.driver.get(referer)
            self.prompt("보안문자가 필요합니다. 열린 브라우저에서 가입을 직접 마친 뒤 계속을 누르세요.")
            self.sync_cookies()
            if self.view(cafe_id) is None:
                return "가입 완료"
            raise ServiceError("브라우저 가입 결과를 확인하지 못했습니다. 승인 대기 여부를 직접 확인하세요.")
        valid = self.json("GET", API + "/cafe-web/cafe-mobile/CafeMemberNicknameValid.json",
                          params={"cafeId": cafe_id, "nickname": nickname})
        result_of(valid)
        info = view.get("mobileCafeApplyBodyInfo", {})
        questions = info.get("applyQuestions", [])
        answers = []
        for index, question in enumerate(questions):
            text = cafe.answers[index] if index < len(cafe.answers) else ""
            selected = answer_for(text, nickname, options.fallback_answers)
            if question.get("questionType") == "S":
                answers.append(selected)
            else:
                count = len(question.get("answerExampleList", []))
                if not selected.isdigit() or not 1 <= int(selected) <= count:
                    raise ServiceError(f"가입 질문 {index + 1}: 객관식 답변 번호를 엑셀에 입력하세요.")
                answers.append(int(selected))
        apply_type = view.get("applyType")
        if apply_type not in ("join", "apply"):
            raise ServiceError("지원하지 않는 가입 유형입니다. 브라우저에서 확인하세요.")
        payload = {"applyType": apply_type, "applyQuestionSetno": info.get("lastsetno"),
                   "nickname": nickname, "cafeProfileImagePath": self.upload_profile(cafe_id, profile) if profile else "",
                   "sexAndAgeConfig": not options.private_profile, "applyAnswerList": answers, "applyImageMap": {}}
        if not info.get("termsOfServiceAgreement"):
            self.driver.get(referer)
            self.prompt("카페 가입 약관을 브라우저에서 확인하세요. 동의하고 가입 요청을 보내려면 계속을 누르세요.")
            payload["agreeCheck"] = True
        if at(view, "mobileCafeApplyProfileInfo.realnameYn") and not options.private_profile:
            payload["realNameYN"] = True
        self.control.checkpoint()
        data = self.json("POST", API + "/cafe-web/cafe-mobile/CafeApply.json",
                         params={"cafeId": cafe_id, "alimCode": info.get("alimCode", ""),
                                 "clubTempId": info.get("clubTempId", ""), "requestFrom": "B"},
                         data={"applyRequestJson": json.dumps(payload, ensure_ascii=False)})
        result = result_of(data)
        # Require a structured success value; never accept a substring in an error message.
        if not (result == "SUCCESS" or result == "success" or
                isinstance(result, dict) and any(result.get(k) in (True, "SUCCESS", "success")
                                                 for k in ("success", "result", "resultCode"))):
            raise ServiceError("가입 결과 형식이 불명확합니다. 브라우저에서 처리 여부를 확인하세요.")
        return "가입 완료" if apply_type == "join" else "승인 대기"

    def visit(self, cafe):
        cafe_id = self.cafe_id(cafe)
        self.request("GET", "https://m.cafe.naver.com/CafeProfile.nhn", params={"cafeId": cafe_id})
        data = self.json("GET", API + "/cafe-web/cafe2/CafeMemberInfo.json", params={"cafeId": cafe_id})
        count = at(result_of(data), "cafeMemberActivity.visitCount")
        self.log(f"{cafe.address}: 출석수 {count if count is not None else '확인 불가'}")

    def favorite(self, cafe):
        result = result_of(self.json("POST", API + "/cafe-home-web/cafe-home/v1/cafes/favorite",
                                     data={"cafeId": self.cafe_id(cafe)}))
        if not (result in (True, "SUCCESS", "success") or isinstance(result, dict) and result.get("success") is True):
            raise ServiceError("즐겨찾기 처리 결과를 확인하지 못했습니다.")

    def post(self, cafe, draft, nickname, options):
        cafe_id = self.cafe_id(cafe)
        editor_url = f"https://cafe.naver.com/ca-fe/cafes/{cafe_id}/menus/{cafe.menu_id}/articles/write?boardType=L"
        headers = {"Referer": editor_url, "Origin": "https://cafe.naver.com", "X-Cafe-Product": "pc"}
        editor = result_of(self.json("GET", f"{API}/cafe-web/cafe-editor-api/v1.0/cafes/{cafe_id}/editor",
                                     params={"experienceMode": "true", "menuId": cafe.menu_id, "from": "pc"}, headers=headers))
        token = editor.get("token")
        if not token:
            raise ServiceError("게시판 쓰기 권한 또는 에디터 토큰을 확인하지 못했습니다.")
        config = self.json("GET", "https://platform.editor.naver.com/api/cafepc001/v1/service_config",
                           headers={**headers, "SE-Authorization": token})
        editor_id = at(config, "editorInfo.id")
        if not editor_id:
            raise ServiceError("에디터 ID를 확인하지 못했습니다.")
        payload = document_payload(cafe_id, cafe.menu_id, editor_id, draft, nickname, options.allow_comments)
        data = self.json("POST", f"{API}/cafe-web/cafe-editor-api/v1.0/cafes/{cafe_id}/menus/{cafe.menu_id}/articles",
                         headers=headers, json=payload)
        article_id = at(result_of(data), "articleId")
        if not article_id:
            raise ServiceError("게시 결과 불명: 게시판에서 확인하세요. 자동 재전송하지 않습니다.")
        return str(article_id)

    def lookup(self, cafe):
        cafe_id = self.cafe_id(cafe)
        return cafe_id

    def close(self):
        try:
            if self.driver:
                self.driver.quit()
        finally:
            self.session.cookies.clear()
            self.session.close()
