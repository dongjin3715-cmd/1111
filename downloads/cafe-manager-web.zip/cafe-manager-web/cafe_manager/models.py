from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse
import csv
import json
import random
import re


@dataclass
class Account:
    username: str
    password: str = field(default="", repr=False)


@dataclass
class Cafe:
    address: str
    answers: list[str] = field(default_factory=lambda: [""] * 5)
    menu_id: str = ""


@dataclass
class Draft:
    title: str
    body: str


@dataclass
class Options:
    delay_min: int = 10
    delay_max: int = 20
    fallback_answers: str = "반갑습니다,잘 부탁드립니다"
    greeting: bool = False
    include_existing: bool = False
    favorite: bool = False
    private_profile: bool = True
    allow_comments: bool = True
    random_profile: bool = False
    manual_login: bool = True
    simulation: bool = True
    auto_save: bool = True
    login_timeout: int = 180

    def validate(self):
        if not 0 <= self.delay_min <= self.delay_max <= 86400:
            raise ValueError("대기시간은 0~86400초이며 최소 ≤ 최대여야 합니다.")
        if not 10 <= self.login_timeout <= 3600:
            raise ValueError("로그인 대기시간은 10~3600초여야 합니다.")
        if not self.fallback_answers.strip():
            raise ValueError("기본 가입 답변을 입력하세요.")


def read_text(path):
    raw = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "cp949"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise ValueError("UTF-8 또는 CP949 텍스트 파일이 필요합니다.")


def load_accounts(path):
    result = []
    for number, line in enumerate(read_text(path).splitlines(), 1):
        if not line.strip():
            continue
        cells = line.split("\t")
        if len(cells) > 2 or not cells[0].strip():
            raise ValueError(f"계정 파일 {number}행: ID 또는 ID<TAB>PW 형식이 필요합니다.")
        result.append(Account(cells[0].strip(), cells[1].strip() if len(cells) > 1 else ""))
    if not result:
        raise ValueError("계정 파일이 비어 있습니다.")
    return result


def cafe_slug(value):
    value = str(value).strip()
    if re.fullmatch(r"[A-Za-z0-9_-]+", value):
        return value
    parsed = urlparse(value if "://" in value else "https://" + value)
    if parsed.scheme != "https" or parsed.hostname not in ("cafe.naver.com", "m.cafe.naver.com"):
        raise ValueError("네이버 카페 HTTPS 주소 또는 영문 카페 주소를 입력하세요.")
    parts = parsed.path.strip("/").split("/")
    if len(parts) == 1 and re.fullmatch(r"[A-Za-z0-9_-]+", parts[0]):
        return parts[0]
    match = re.fullmatch(r"ca-fe/(?:web/)?cafes/(\d+)(?:/.*)?", parsed.path.strip("/"))
    if match:
        return match[1]
    raise ValueError("카페 홈 주소를 입력하세요. 게시글 주소는 지원하지 않습니다.")


def cell_text(cell):
    if cell is None:
        return ""
    if isinstance(cell, float) and cell.is_integer():
        return str(int(cell))
    return str(cell).strip()


def load_cafes(path):
    from openpyxl import load_workbook
    book = load_workbook(path, read_only=True, data_only=True)
    result = []
    try:
        for number, row in enumerate(book.worksheets[0].iter_rows(values_only=True), 1):
            cells = [cell_text(v) for v in row[:7]]
            cells += [""] * (7 - len(cells))
            if not any(cells):
                continue
            if number == 1 and cells[0].lower() in ("카페", "카페주소", "카페 주소", "카페url", "카페 url", "url", "cafe"):
                continue
            try:
                address = cafe_slug(cells[0])
                if cells[6] and not cells[6].isdigit():
                    raise ValueError("메뉴 ID는 숫자여야 합니다.")
            except ValueError as exc:
                raise ValueError(f"엑셀 {number}행: {exc}") from None
            result.append(Cafe(address, cells[1:6], cells[6]))
    finally:
        book.close()
    if not result:
        raise ValueError("카페 목록이 비어 있습니다.")
    return result


def load_lines(path):
    values = [s.strip() for s in read_text(path).splitlines() if s.strip()]
    if not values:
        raise ValueError("파일이 비어 있습니다.")
    return values


def load_drafts(folder):
    drafts = []
    for path in sorted(Path(folder).glob("*.txt")):
        lines = read_text(path).splitlines()
        if len(lines) < 2 or not lines[0].strip() or not "\n".join(lines[1:]).strip():
            raise ValueError(f"{path.name}: 첫 줄 제목, 둘째 줄부터 본문을 입력하세요.")
        drafts.append(Draft(lines[0].strip(), "\n".join(lines[1:])))
    if not drafts:
        raise ValueError("폴더에 원고 TXT 파일이 없습니다.")
    return drafts


def answer_for(text, nickname, fallback, rng=random):
    choices = [s.strip() for s in (text or fallback).split(",") if s.strip()]
    if not choices:
        raise ValueError("가입 질문 답변이 비어 있습니다.")
    return rng.choice(choices).replace("[닉네임]", nickname)


def export_history(path, records):
    # Spreadsheet formula injection is prevented even for user-supplied cafe/account names.
    def safe(value):
        value = str(value)
        return "'" + value if value.startswith(("=", "+", "-", "@", "\t", "\r")) else value
    with open(path, "w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["계정", "카페", "닉네임", "시간", "결과"])
        writer.writerows([safe(v) for v in row] for row in records)


def save_options(path, options):
    from dataclasses import asdict
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(asdict(options), ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def load_options(path):
    if not Path(path).exists():
        return Options()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    allowed = Options.__dataclass_fields__
    options = Options(**{k: v for k, v in data.items() if k in allowed})
    # A restart always starts in simulation mode.
    options.simulation = True
    options.validate()
    return options
