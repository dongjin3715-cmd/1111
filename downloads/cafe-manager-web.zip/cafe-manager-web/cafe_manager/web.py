"""Loopback-only single-user web application. Network work runs off the request thread."""
import copy
import io
import json
import os
import secrets
import sys
import tempfile
import threading
import time
import webbrowser
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from flask import Flask, abort, jsonify, render_template, request, send_file

from .adapters import NaverAdapter
from .engine import Cancelled, Control, Engine, SimulationAdapter
from .models import (Account, Cafe, Options, cafe_slug, export_history, load_accounts,
                     load_cafes, load_drafts, load_lines, load_options, save_options)


def data_directory():
    override = os.environ.get("CAFE_MANAGER_DATA_DIR")
    if override:
        return Path(override)
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share")))
    return base / "CafeManagerWeb"


class State:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.accounts, self.cafes, self.nicknames, self.drafts, self.profiles = [], [], [], [], []
        self.records, self.logs = [], []
        self.status, self.progress, self.total = "준비", 0, 0
        self.question = None
        self.reply = threading.Event()
        self.answer = False
        self.control = None
        self.thread = None
        self.simulation = True
        self.run_stamp = ""
        self.autosave = True
        self.log_counter = 0
        try:
            self.options = load_options(self.folder / "options.json")
        except (OSError, ValueError, TypeError):
            self.options = Options()

    def busy(self):
        return self.thread is not None and self.thread.is_alive()

    def snapshot(self):
        with self.lock:
            return {"accounts": [{"username": a.username, "has_password": bool(a.password)} for a in self.accounts],
                    "cafes": [asdict(c) for c in self.cafes], "nickname_count": len(self.nicknames),
                    "draft_count": len(self.drafts), "profile_count": len(self.profiles),
                    "options": asdict(self.options), "status": self.status,
                    "busy": self.busy(), "paused": bool(self.control and not self.control.running.is_set()),
                    "simulation": self.simulation, "progress": self.progress, "total": self.total,
                    "question": copy.deepcopy(self.question), "records": copy.deepcopy(self.records),
                    "logs": copy.deepcopy(self.logs)}

    def log(self, text):
        with self.lock:
            self.log_counter += 1
            self.logs.append({"id": self.log_counter, "time": datetime.now().strftime("%H:%M:%S"), "text": text})
            self.logs = self.logs[-1000:]

    def emit(self, kind, value):
        with self.lock:
            if kind == "log":
                self.log(value)
            elif kind == "record":
                row = list(value)
                if self.simulation:
                    row[4] = "[모의] " + row[4]
                self.records.append(row)
                if self.autosave:
                    folder = self.folder / "history"
                    folder.mkdir(exist_ok=True)
                    path = folder / f"{'simulation' if self.simulation else 'live'}-{self.run_stamp}.csv"
                    temporary = path.with_suffix(".tmp")
                    try:
                        export_history(temporary, self.records)
                        temporary.replace(path)
                    except OSError:
                        self.log("자동 저장 실패: 저장 폴더의 권한과 여유 공간을 확인하세요.")
            elif kind == "progress":
                self.progress, self.total = value
            elif kind == "finished":
                self.status = value
                self.log("작업 " + value)

    def prompt(self, text):
        with self.lock:
            self.reply.clear()
            self.question = {"id": secrets.token_hex(12), "text": text}
        try:
            while not self.reply.wait(.1):
                self.control.checkpoint()
            self.control.checkpoint()
            if not self.answer:
                self.control.stop()
                raise Cancelled()
            return True
        finally:
            with self.lock:
                self.question = None


def create_app(folder=None, adapter_factory=None):
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    app = Flask(__name__, template_folder=str(base / "web"), static_folder=str(base / "web" / "static"))
    app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
    app.config["TRUSTED_HOSTS"] = ["localhost", "127.0.0.1"]
    state = State(folder or data_directory())
    token = secrets.token_urlsafe(32)
    app.extensions["state"] = state
    app.extensions["csrf_token"] = token

    @app.before_request
    def check_local():
        if request.remote_addr not in (None, "127.0.0.1", "::1"):
            abort(403)
        if request.path.startswith("/api/"):
            provided = request.headers.get("X-App-Token", "")
            if not secrets.compare_digest(provided, token):
                abort(403)
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("Origin")
            if origin and origin != request.host_url.rstrip("/"):
                abort(403)

    @app.after_request
    def secure_response(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        return response

    @app.errorhandler(ValueError)
    def value_error(error):
        return jsonify(error=str(error)), 400

    @app.errorhandler(413)
    def too_large(error):
        return jsonify(error="업로드는 한 번에 20MB까지 가능합니다."), 413

    def idle():
        if state.busy():
            abort(409, description="작업 중에는 입력을 변경할 수 없습니다.")

    @app.get("/")
    def index():
        return render_template("index.html", token=token)

    @app.get("/api/state")
    def snapshot():
        return jsonify(state.snapshot())

    @app.post("/api/accounts")
    def accounts():
        with state.lock:
            idle()
            data = request.get_json()
            if data.get("clear"):
                state.accounts.clear()
            else:
                username = str(data.get("username", "")).strip()
                if not username or len(username) > 100 or any(c in username for c in "\r\n\t"):
                    raise ValueError("올바른 네이버 ID를 입력하세요.")
                state.accounts.append(Account(username, str(data.get("password", ""))))
        return jsonify(ok=True)

    @app.post("/api/cafes")
    def cafes():
        with state.lock:
            idle()
            data = request.get_json()
            rows = data.get("cafes", [])
            if not isinstance(rows, list) or len(rows) > 1000:
                raise ValueError("카페는 최대 1000개까지 입력할 수 있습니다.")
            values = []
            for row in rows:
                answers = row.get("answers", [])
                menu = str(row.get("menu_id", "")).strip()
                if menu and not menu.isdigit():
                    raise ValueError("메뉴 ID는 숫자여야 합니다.")
                values.append(Cafe(cafe_slug(row.get("address", "")),
                                   [str(v) for v in answers[:5]] + [""] * max(0, 5 - len(answers)), menu))
            state.cafes = values
        return jsonify(ok=True)

    @app.post("/api/options")
    def options():
        with state.lock:
            idle()
            data = request.get_json()
            fields = Options.__dataclass_fields__
            values = {key: data[key] for key in fields if key in data}
            for key, value in values.items():
                default = getattr(Options(), key)
                if type(value) is not type(default):
                    raise ValueError(f"옵션 형식을 확인하세요: {key}")
            value = Options(**values)
            value.validate()
            save_options(state.folder / "options.json", value)
            state.options = value
        return jsonify(ok=True)

    @app.post("/api/import/<kind>")
    def import_file(kind):
        with state.lock:
            idle()
            files = request.files.getlist("files")
            if not files:
                raise ValueError("파일을 선택하세요.")
            with tempfile.TemporaryDirectory(prefix="cafe-import-") as folder:
                temporary = Path(folder)
                if kind in ("accounts", "cafes", "nicknames"):
                    suffix = ".xlsx" if kind == "cafes" else ".txt"
                    path = temporary / ("input" + suffix)
                    files[0].save(path)
                    loader = {"accounts": load_accounts, "cafes": load_cafes, "nicknames": load_lines}[kind]
                    setattr(state, kind, loader(path))
                elif kind == "drafts":
                    selected = [f for f in files if f.filename and f.filename.lower().endswith(".txt")]
                    for number, file in enumerate(selected):
                        file.save(temporary / f"{number:04}.txt")
                    state.drafts = load_drafts(temporary)
                elif kind == "profiles":
                    paths = []
                    profile_dir = state.folder / "profiles"
                    profile_dir.mkdir(exist_ok=True)
                    from PIL import Image
                    # Decode/re-encode to avoid storing arbitrary files supplied as profile images.
                    for file in files:
                        path = profile_dir / (secrets.token_hex(12) + ".png")
                        try:
                            image = Image.open(file.stream)
                            if image.width * image.height > 20_000_000:
                                raise ValueError("프로필 이미지는 2000만 화소 이하로 선택하세요.")
                            image.convert("RGB").save(path, "PNG")
                        except Exception:
                            for saved in paths:
                                Path(saved).unlink(missing_ok=True)
                            raise ValueError("읽을 수 있는 JPG 또는 PNG 이미지를 선택하세요.") from None
                        paths.append(str(path))
                    for old in state.profiles:
                        Path(old).unlink(missing_ok=True)
                    state.profiles = paths
                else:
                    abort(404)
        return jsonify(ok=True)

    @app.post("/api/start")
    def start():
        with state.lock:
            idle()
            options = copy.deepcopy(state.options)
            options.validate()
            if not state.accounts or not state.cafes:
                raise ValueError("계정과 카페 목록이 필요합니다.")
            if options.greeting and not state.drafts:
                raise ValueError("가입인사 원고 파일이 필요합니다.")
            data = request.get_json(silent=True) or {}
            if not options.simulation and data.get("confirm_live") is not True:
                raise ValueError("실제 가입·게시 작업 시작을 확인하세요.")
            if not options.simulation and not options.manual_login and any(not a.password for a in state.accounts):
                raise ValueError("자동 로그인에 필요한 계정 비밀번호가 없습니다.")
            state.control = Control()
            state.records, state.logs = [], []
            state.simulation, state.autosave = options.simulation, options.auto_save
            state.run_stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            state.status, state.progress = "실행 중", 0
            state.total = len(state.accounts) * len(state.cafes)
            factory = adapter_factory or (SimulationAdapter if options.simulation else NaverAdapter)
            engine = Engine(copy.deepcopy(state.accounts), copy.deepcopy(state.cafes), list(state.nicknames),
                            copy.deepcopy(state.drafts), list(state.profiles), options, factory,
                            state.emit, state.prompt, state.control)

            def run():
                try:
                    engine.run()
                except Exception as exc:
                    state.log("작업 오류: " + type(exc).__name__)
                    state.status = "오류"
                finally:
                    with state.lock:
                        state.question = None
                        if state.status == "실행 중":
                            state.status = "완료"

            state.thread = threading.Thread(target=run, daemon=True, name="cafe-worker")
            state.thread.start()
        return jsonify(ok=True)

    @app.post("/api/control/<action>")
    def control(action):
        with state.lock:
            if not state.busy():
                raise ValueError("실행 중인 작업이 없습니다.")
            if action == "pause":
                state.control.pause()
                state.status = "일시정지"
            elif action == "resume":
                state.control.resume()
                state.status = "실행 중"
            elif action == "stop":
                state.control.stop()
                state.status = "중지 중"
            else:
                abort(404)
        return jsonify(ok=True)

    @app.post("/api/reply")
    def reply():
        with state.lock:
            data = request.get_json()
            if not state.question or data.get("id") != state.question["id"]:
                raise ValueError("확인 요청이 만료되었습니다.")
            state.answer = data.get("continue") is True
            if not state.answer:
                state.control.stop()
            else:
                state.control.resume()
                state.status = "실행 중"
            state.reply.set()
        return jsonify(ok=True)

    @app.get("/api/export")
    def export():
        with state.lock:
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "history.csv"
                export_history(path, state.records)
                content = io.BytesIO(path.read_bytes())
        return send_file(content, mimetype="text/csv; charset=utf-8", as_attachment=True, download_name="cafe-history.csv")

    @app.post("/api/lookup")
    def lookup():
        cafe = Cafe(cafe_slug(request.get_json().get("address", "")))
        adapter = NaverAdapter(Control(), lambda _: None, lambda _: None)
        try:
            return jsonify(cafe_id=adapter.lookup(cafe))
        except Exception as exc:
            return jsonify(error=adapter.safe_error(exc)), 502
        finally:
            adapter.close()

    return app


def main():
    from werkzeug.serving import make_server
    import argparse
    parser = argparse.ArgumentParser(description="카페 매니저 로컬 웹 앱")
    parser.add_argument("--port", type=int, default=5050)
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args()
    app = create_app()
    server = make_server("127.0.0.1", args.port, app, threaded=True)
    if not args.no_open:
        threading.Timer(.5, lambda: webbrowser.open(f"http://127.0.0.1:{args.port}")).start()
    print("Cafe Manager started. Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        state = app.extensions["state"]
        if state.control:
            state.control.stop()
        if state.thread:
            state.thread.join(timeout=60)
        server.server_close()
