@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller==6.16.0
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --name CafeManager --collect-all selenium --add-data "web;web" main.py
if errorlevel 1 goto fail
echo Built: dist\CafeManager\CafeManager.exe
pause
exit /b 0
:fail
echo Build failed. Please read the error above.
pause
exit /b 1
