import io
import json
import threading
import time
from dataclasses import asdict

import pytest
import requests
from openpyxl import Workbook

from cafe_manager.adapters import NaverAdapter, ServiceError, document_payload
from cafe_manager.engine import Cancelled, Control, Engine, SimulationAdapter
from cafe_manager.models import Account, Cafe, Draft, Options, answer_for, cafe_slug, load_accounts, load_cafes
from cafe_manager.web import create_app


@pytest.fixture
def web(tmp_path):
    app = create_app(tmp_path)
    app.config['TESTING'] = True
    return app, app.test_client(), {'X-App-Token': app.extensions['csrf_token']}


def test_account_file_does_not_expose_password_in_repr(tmp_path):
    file = tmp_path / 'accounts.txt'
    file.write_text('test-user\tvery-private\nmanual-user\n', encoding='utf-8')
    accounts = load_accounts(file)
    assert accounts[0].password == 'very-private'
    assert accounts[1].password == ''
    assert 'very-private' not in repr(accounts)


def test_excel_compatible_with_original_columns(tmp_path):
    book = Workbook()
    book.active.append(['카페 주소', '답변1', '답변2', '답변3', '답변4', '답변5', '메뉴'])
    book.active.append(['https://cafe.naver.com/sample', '[닉네임]', 2, None, '예', '확인', 15])
    book.active.append([None] * 7)
    file = tmp_path / 'cafes.xlsx'
    book.save(file)
    cafes = load_cafes(file)
    assert cafes == [Cafe('sample', ['[닉네임]', '2', '', '예', '확인'], '15')]


@pytest.mark.parametrize('address', ['https://evil.test/cafe', 'https://cafe.naver.com.evil.test/name', 'file:///etc/passwd', 'https://cafe.naver.com/name/123'])
def test_cafe_address_rejects_unsupported_targets(address):
    with pytest.raises(ValueError):
        cafe_slug(address)


def test_replacement_and_random_choices():
    class RNG:
        def choice(self, values):
            return values[-1]
    assert answer_for('첫째,[닉네임]님 반갑습니다', '테스트', '', RNG()) == '테스트님 반갑습니다'


def test_post_json_escapes_quotes_and_newlines():
    value = document_payload('123', '7', 'editor', Draft('제목 "따옴표"', '[닉네임]\n본문 "text"'), '닉', False)
    article = json.loads(json.dumps(value))['article']
    document = json.loads(article['contentJson'])['document']
    assert article['enableComment'] is False
    assert article['subject'] == '제목 "따옴표"'
    assert document['components'][0]['value'][1]['nodes'][0]['value'] == '본문 "text"'


def test_engine_skips_posts_for_pending_membership():
    calls = []
    class Pending(SimulationAdapter):
        def join(self, *args): return '승인 대기'
        def post(self, *args): calls.append('post')
    options = Options(greeting=True, delay_min=0, delay_max=0)
    engine = Engine([Account('test')], [Cafe('sample', menu_id='2')], [], [Draft('Hi', 'Body')], [], options, Pending)
    engine.run()
    assert engine.records[0][-1] == '승인 대기'
    assert not calls


@pytest.mark.parametrize('include,posts', [(False, 0), (True, 1)])
def test_engine_existing_member_option(include, posts):
    calls = []
    class Existing(SimulationAdapter):
        def join(self, *args): return '이미 가입'
        def post(self, *args): calls.append('post'); return '12'
    options = Options(greeting=True, include_existing=include, delay_min=0, delay_max=0)
    Engine([Account('test')], [Cafe('sample', menu_id='2')], [], [Draft('Hi', 'Body')], [], options, Existing).run()
    assert len(calls) == posts


def test_stop_interrupts_paused_worker():
    control = Control()
    control.pause()
    interrupted = threading.Event()
    def run():
        try: control.wait(100)
        except Cancelled: interrupted.set()
    thread = threading.Thread(target=run)
    thread.start()
    control.stop()
    thread.join(1)
    assert interrupted.is_set() and not thread.is_alive()


def test_ambiguous_post_is_not_retried():
    class Session:
        headers = {}
        calls = 0
        def request(self, *args, **kwargs):
            self.calls += 1
            raise requests.Timeout('secret-token')
    session = Session()
    adapter = NaverAdapter(Control(), lambda _: '', lambda _: None, session=session)
    with pytest.raises(ServiceError, match='결과 불명') as caught:
        adapter.request('POST', 'https://apis.naver.com/example')
    assert session.calls == 1
    assert 'secret-token' not in str(caught.value)


def test_api_requires_token_and_rejects_cross_origin(web):
    app, client, headers = web
    assert client.get('/api/state').status_code == 403
    assert client.post('/api/accounts', json={'username':'test'}, headers={**headers, 'Origin':'https://evil.test'}).status_code == 403
    assert client.get('/', headers={'Host':'evil.test'}).status_code == 400
    assert client.get('/').status_code == 200


def test_web_simulation_end_to_end_and_password_redaction(web):
    app, client, headers = web
    assert client.post('/api/accounts', json={'username':'test-user', 'password':'do-not-expose'}, headers=headers).status_code == 200
    assert client.post('/api/cafes', json={'cafes':[{'address':'sample', 'answers':[], 'menu_id':'2'}]}, headers=headers).status_code == 200
    options = asdict(Options(delay_min=0, delay_max=0))
    assert client.post('/api/options', json=options, headers=headers).status_code == 200
    assert client.post('/api/start', json={}, headers=headers).status_code == 200
    app.extensions['state'].thread.join(2)
    response = client.get('/api/state', headers=headers)
    state = response.get_json()
    assert state['status'] == '완료' and state['progress'] == 1
    assert state['records'][0][-1] == '[모의] 가입 완료'
    assert 'do-not-expose' not in response.get_data(as_text=True)
    exported = client.get('/api/export', headers=headers).data.decode('utf-8-sig')
    assert '[모의] 가입 완료' in exported and 'do-not-expose' not in exported
    assert list(app.extensions['state'].folder.glob('history/simulation-*.csv'))


def test_live_start_needs_explicit_confirmation(web):
    app, client, headers = web
    client.post('/api/accounts', json={'username':'test'}, headers=headers)
    client.post('/api/cafes', json={'cafes':[{'address':'sample'}]}, headers=headers)
    client.post('/api/options', json=asdict(Options(simulation=False)), headers=headers)
    result = client.post('/api/start', json={}, headers=headers)
    assert result.status_code == 400 and app.extensions['state'].thread is None


def test_uploads_and_csv_formula_protection(web):
    app, client, headers = web
    response = client.post('/api/import/accounts', data={'files':(io.BytesIO(b'test\tsecret\n'), 'accounts.txt')}, headers=headers)
    assert response.status_code == 200
    state = app.extensions['state']
    state.records = [['=1+1', 'sample', 'nickname', 'time', 'result']]
    response = client.get('/api/export', headers=headers)
    assert "'=1+1" in response.data.decode('utf-8-sig')


def test_cancel_prompt_unblocks_worker(tmp_path):
    from cafe_manager.web import State
    state = State(tmp_path)
    state.control = Control()
    stopped = threading.Event()
    def run():
        try: state.prompt('test')
        except Cancelled: stopped.set()
    thread = threading.Thread(target=run)
    thread.start()
    deadline = time.monotonic() + 2
    while state.question is None and time.monotonic() < deadline:
        time.sleep(.01)
    state.control.stop()
    thread.join(1)
    assert stopped.is_set() and state.question is None


@pytest.mark.parametrize('server_result,expected', [('SUCCESS', '가입 완료'), ({'success': True}, '가입 완료')])
def test_join_request_contract(server_result, expected):
    calls = []
    class Adapter(NaverAdapter):
        def cafe_id(self, cafe): return '123'
        def view(self, cafe_id):
            return {'applyType':'join', 'mobileCafeApplyBodyInfo':{
                'lastsetno': 2, 'alimCode':'a', 'clubTempId':'b', 'termsOfServiceAgreement':True,
                'applyQuestions':[{'questionType':'S'},{'questionType':'M','answerExampleList':['a','b']}]}}
        def json(self, method, url, **kwargs):
            calls.append((method, url, kwargs))
            if method == 'GET': return {'message':{'status':'200','result':{}}}
            return {'message':{'status':'200','result':server_result}}
    adapter = Adapter(Control(), lambda _: True, lambda _: None)
    cafe = Cafe('sample', ['[닉네임]입니다','2','','',''])
    assert adapter.join(cafe, '새닉네임', None, Options()) == expected
    payload = json.loads(calls[-1][2]['data']['applyRequestJson'])
    assert payload['applyAnswerList'] == ['새닉네임입니다', 2]
    assert payload['sexAndAgeConfig'] is False
    assert len([c for c in calls if c[0] == 'POST']) == 1


def test_join_never_interprets_error_substring_as_success():
    class Adapter(NaverAdapter):
        def cafe_id(self, cafe): return '123'
        def view(self, cafe_id): return {'applyType':'join', 'mobileCafeApplyBodyInfo':{'termsOfServiceAgreement':True}}
        def json(self, method, url, **kwargs):
            return {'message':{'status':'200','result': {'detail':'not success'}}}
    adapter = Adapter(Control(), lambda _: True, lambda _: None)
    with pytest.raises(ServiceError, match='불명확'):
        adapter.join(Cafe('sample'), '닉네임', None, Options())


def test_unsupported_objective_answer_does_not_send_join():
    calls = []
    class Adapter(NaverAdapter):
        def cafe_id(self, cafe): return '123'
        def view(self, cafe_id):
            return {'applyType':'join','mobileCafeApplyBodyInfo':{'applyQuestions':[
                {'questionType':'M','answerExampleList':['a']}], 'termsOfServiceAgreement':True}}
        def json(self, method, url, **kwargs):
            calls.append(method)
            return {'message':{'status':'200','result':{}}}
    adapter = Adapter(Control(), lambda _: True, lambda _: None)
    with pytest.raises(ServiceError, match='객관식'):
        adapter.join(Cafe('sample', ['3']), '닉네임', None, Options())
    assert calls == ['GET']
