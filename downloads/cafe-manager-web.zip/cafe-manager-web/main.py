from cafe_manager.web import main

if __name__ == "__main__":
    raise SystemExit(main())
