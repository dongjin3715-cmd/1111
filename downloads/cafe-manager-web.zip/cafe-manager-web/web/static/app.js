'use strict';
const $ = id => document.getElementById(id);
const token = document.querySelector('meta[name="app-token"]').content;
let current = null, uploadKind = '', noticeTimer, polling = false, starting = false;

async function api(path, data, method = 'POST') {
  const headers = {'X-App-Token': token};
  const options = {method, headers};
  if (data instanceof FormData) options.body = data;
  else if (data !== undefined) { headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data); }
  const response = await fetch('/api/' + path, options);
  const text = await response.text();
  let result;
  try { result = JSON.parse(text); } catch (_) { result = {}; }
  if (!response.ok) throw new Error(result.error || `요청 실패 (${response.status}). 서버 상태를 확인하세요.`);
  return result;
}

function error(error) { $('error').textContent = error.message || String(error); $('error').hidden = false; }
function notice(text) { $('notice').textContent = text; $('notice').hidden = false; clearTimeout(noticeTimer); noticeTimer = setTimeout(() => $('notice').hidden = true, 4500); }
function action(fn) { return async event => { if (event) event.preventDefault(); $('error').hidden = true; try { await fn(event); } catch (e) { error(e); } }; }
function cell(text) { const td = document.createElement('td'); td.textContent = text; return td; }

function addCafe(cafe = {address:'', answers:['','','','',''], menu_id:''}) {
  const row = document.createElement('tr');
  [cafe.address, ...cafe.answers, cafe.menu_id].forEach((value, index) => {
    const td = document.createElement('td'), input = document.createElement('input');
    input.value = value; input.setAttribute('aria-label', ['카페 주소','답변 1','답변 2','답변 3','답변 4','답변 5','메뉴 ID'][index]);
    if (index === 6) input.inputMode = 'numeric';
    input.className = 'edit-control'; td.append(input); row.append(td);
  });
  const tools = document.createElement('td'), lookup = document.createElement('button'), remove = document.createElement('button');
  lookup.textContent = 'ID'; lookup.title = '카페 ID 조회'; lookup.className = 'edit-control';
  lookup.onclick = action(async () => { const value = await api('lookup', {address: row.querySelector('input').value}); notice('카페 ID: ' + value.cafe_id + ' · 메뉴 ID는 게시판 주소에서 확인하세요.'); });
  remove.textContent = '삭제'; remove.className = 'edit-control'; remove.onclick = () => { row.remove(); tableCount(); };
  tools.append(lookup, remove); row.append(tools); $('cafes').append(row); tableCount();
}

function tableCount() { const count = $('cafes').children.length; $('table-count').textContent = count + '개'; $('cafes-empty').hidden = count > 0; }
function cafeValues() { return [...$('cafes').querySelectorAll('tr')].map(row => { const values = [...row.querySelectorAll('input')].map(input => input.value); return {address:values[0], answers:values.slice(1,6), menu_id:values[6]}; }).filter(row => row.address.trim()); }
function optionsValues() { const values = {}; for (const input of $('options-form').elements) if (input.name) values[input.name] = input.type === 'checkbox' ? input.checked : input.type === 'number' ? Number(input.value) : input.value; return values; }
function mode(simulation) {
  $('mode-title').textContent = simulation ? '모의 실행 모드' : '실제 실행 모드';
  $('mode-description').textContent = simulation ? '실제 네이버 요청 없이 작업 흐름을 확인합니다.' : '작업 시작 시 선택한 계정으로 실제 가입·게시 요청을 전송합니다.';
  $('mode-banner').classList.toggle('live', !simulation);
}

function render(state, full = false) {
  current = state;
  $('connection').textContent = '로컬 서버 연결됨';
  $('account-count').replaceChildren(document.createTextNode(state.accounts.length), Object.assign(document.createElement('small'), {textContent:'개'}));
  $('cafe-count').replaceChildren(document.createTextNode(state.cafes.length), Object.assign(document.createElement('small'), {textContent:'개'}));
  $('draft-count').replaceChildren(document.createTextNode(state.draft_count), Object.assign(document.createElement('small'), {textContent:'개'}));
  $('nickname-count').textContent = state.nickname_count + '개'; $('drafts-count').textContent = state.draft_count + '개'; $('profile-count').textContent = state.profile_count + '개';
  $('accounts').replaceChildren();
  if (!state.accounts.length) { const empty = document.createElement('div'); empty.className = 'empty'; empty.textContent = '아직 등록된 계정이 없습니다.'; $('accounts').append(empty); }
  for (const account of state.accounts) { const row = document.createElement('div'); row.className = 'account-item'; const id = document.createElement('span'), password = document.createElement('span'); id.textContent = account.username; password.textContent = account.has_password ? '••••••••' : '수동 로그인'; row.append(id, password); $('accounts').append(row); }
  if (full) {
    $('cafes').replaceChildren(); state.cafes.forEach(addCafe); tableCount();
    for (const [key, value] of Object.entries(state.options)) { const input = $('options-form').elements.namedItem(key); if (input) { if (input.type === 'checkbox') input.checked = value; else input.value = value; } }
  }
  $('status').textContent = state.status; $('run-status').textContent = state.busy ? state.status : state.status === '준비' ? '작업을 시작할 준비가 되었습니다.' : state.status + (state.simulation ? ' · 모의 실행' : '');
  $('progress').max = Math.max(state.total, 1); $('progress').value = state.progress; $('progress-label').textContent = `${state.progress} / ${state.total}`;
  $('start').disabled = state.busy || starting; $('stop').disabled = !state.busy; $('pause').disabled = !state.busy;
  $('pause').textContent = state.paused ? '계속' : '일시정지';
  document.querySelectorAll('.edit-control, #options-form input, #account-form input').forEach(input => input.disabled = state.busy || starting);
  mode(state.busy ? state.simulation : $('options-form').elements.namedItem('simulation').checked);
  $('history-rows').replaceChildren();
  for (const record of state.records) { const tr = document.createElement('tr'); record.forEach(value => tr.append(cell(value))); $('history-rows').append(tr); }
  const log = $('log-text'), nearBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
  log.textContent = state.logs.length ? state.logs.map(entry => entry.time + '  ' + entry.text).join('\n') : '실행을 기다리고 있습니다.';
  if (nearBottom) log.scrollTop = log.scrollHeight;
  const dialog = $('question-dialog');
  if (state.question) { dialog.dataset.id = state.question.id; $('question-text').textContent = state.question.text; if (!dialog.open) dialog.showModal(); }
  else if (dialog.open) dialog.close();
}

async function refresh(full = false) { const state = await api('state', undefined, 'GET'); render(state, full); }
function upload(kind, accept, multiple = false) { uploadKind = kind; const input = $('file-input'); input.value = ''; input.accept = accept; input.multiple = multiple; input.click(); }

document.querySelectorAll('.nav').forEach(button => button.onclick = () => {
  document.querySelectorAll('.nav,.page').forEach(element => element.classList.remove('active'));
  button.classList.add('active'); $(button.dataset.page).classList.add('active'); $('page-title').textContent = button.textContent;
});
$('account-form').onsubmit = action(async () => { await api('accounts', {username:$('username').value, password:$('password').value}); $('username').value = ''; $('password').value = ''; await refresh(); });
$('clear-accounts').onclick = action(async () => { await api('accounts', {clear:true}); await refresh(); });
$('account-import').onclick = () => upload('accounts', '.txt');
$('cafes-import').onclick = () => upload('cafes', '.xlsx');
$('nicknames-import').onclick = () => upload('nicknames', '.txt');
$('drafts-import').onclick = () => upload('drafts', '.txt', true);
$('profiles-import').onclick = () => upload('profiles', '.png,.jpg,.jpeg', true);
$('file-input').onchange = action(async () => { const files = $('file-input').files; if (!files.length) return; const body = new FormData(); for (const file of files) body.append('files', file); await api('import/' + uploadKind, body); await refresh(uploadKind === 'cafes'); notice('파일을 불러왔습니다.'); });
$('add-cafe').onclick = () => addCafe();
$('save-cafes').onclick = action(async () => { await api('cafes', {cafes:cafeValues()}); await refresh(); notice('카페 목록을 적용했습니다.'); });
$('save-options').onclick = action(async () => { await api('options', optionsValues()); notice('옵션을 저장했습니다.'); });
$('options-form').onsubmit = event => event.preventDefault();
$('options-form').elements.namedItem('simulation').onchange = event => mode(event.target.checked);
$('start').onclick = action(async () => {
  if (starting || current?.busy) return;
  const options = optionsValues();
  if (!options.simulation && !window.confirm('선택한 계정으로 실제 카페 가입 요청' + (options.greeting ? '과 가입인사 게시' : '') + '를 실행합니다. 계속할까요?')) return;
  starting = true; $('start').disabled = true;
  try { await api('cafes', {cafes:cafeValues()}); await api('options', options); await api('start', {confirm_live:!options.simulation}); }
  finally { starting = false; await refresh(); }
});
$('pause').onclick = action(async () => { await api('control/' + (current.paused ? 'resume' : 'pause'), {}); await refresh(); });
$('stop').onclick = action(async () => { await api('control/stop', {}); await refresh(); });
async function reply(yes) { await api('reply', {id:$('question-dialog').dataset.id, continue:yes}); $('question-dialog').close(); await refresh(); }
$('question-ok').onclick = action(() => reply(true)); $('question-cancel').onclick = action(() => reply(false));
$('question-dialog').addEventListener('cancel', event => { event.preventDefault(); });
$('export').onclick = action(async () => { const response = await fetch('/api/export', {headers:{'X-App-Token':token}}); if (!response.ok) throw new Error('다운로드에 실패했습니다.'); const url = URL.createObjectURL(await response.blob()); const link = document.createElement('a'); link.href = url; link.download = 'cafe-history.csv'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); });
window.addEventListener('beforeunload', event => { if (current?.busy) { event.preventDefault(); event.returnValue = ''; } });
refresh(true).catch(error);
setInterval(async () => { if (polling) return; polling = true; try { await refresh(); } catch (_) { $('connection').textContent = '연결 끊김'; } finally { polling = false; } }, 1000);
